1. Try to run SamplewindowsApp.exe
2. If you get a message "Your Environment is All Set", you are good to run the validator program on the day of workshop
3. if "SamplewindowsApp.exe" utility does not launch on your laptop, use any of the following options to install .net runtime 
   a) please install .net runtime 4.72 by running "ndp472-kb4054531-web.exe" in this folder.
   b) download from link below and install it.
      https://dotnet.microsoft.com/en-us/download/dotnet-framework/net472
4. After installation of .net runtime is complete, Try running "SamplewindowsApp.exe" again. It is expcted to be launched this time.